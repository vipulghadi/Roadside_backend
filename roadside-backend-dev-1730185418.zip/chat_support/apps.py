from django.apps import AppConfig


class ChatSupportConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chat_support'
